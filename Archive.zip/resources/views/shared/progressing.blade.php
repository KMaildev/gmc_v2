<span style="color: red">
    {{ $title }}
</span>

<span style="color: green">
    {{ $message }}
</span>

{{-- @include('shared.progressing', [
    'message' =>
        'Closing Banlance is In Progressing so the result in Cash Balance cannot be right. Now, if this part is exactly finish, we will keep on to write the next step including the Closing Balance. Thanks alot! ',
]) --}}
