@extends('layouts.menus.accounting')
@section('content')

<div class="row justify-content-center py-5">
    <div class="col-md-8 col-sm-12 col-lg-8">



    </div>
</div>

@endsection